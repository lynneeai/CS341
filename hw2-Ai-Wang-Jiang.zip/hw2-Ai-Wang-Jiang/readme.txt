In part1, the user can press the direction key "UP" to switch between the regular spiral and Fermat spiral.

In part3, the earth's speed is changing but the speed does not follow exactly the physical law because the exact formula is complecated. The current equation used to adjust the speed is just for demostration.
