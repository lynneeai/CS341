// glew must be before glfw
#include <GL/glew.h>
#include <GLFW/glfw3.h>

// contains helper functions such as shader compiler
#include "icg_helper.h"

#include <glm/gtc/matrix_transform.hpp>

#include "triangle/triangle.h"

Triangle triangle;

void Init() {
    // sets background color
    glClearColor(0.937, 0.937, 0.937 /*gray*/, 1.0 /*solid*/);

    triangle.Init();
}

void Display_fermat() {
    glClear(GL_COLOR_BUFFER_BIT);

    // compute transformations here
    int N = 400;
    float scale_factor = 0.02f;
    float c = 0.04f;
    float fermat = 137.508f / 2.0;
    for (int i = 0; i < N; i ++){
        float theta = i * fermat * (float)M_PI / 180.0f;
        float r = c * sqrt(theta);
        glm::mat4 T = glm::translate(glm::mat4(1.0f),
                                     glm::vec3(r * cos(theta) , -r * sin(theta) ,0.0f));
        glm::mat4 R = glm::rotate(glm::mat4(1.0f), -theta,
                                  glm::vec3(0.0f, 0.0f, 1.0f));
        glm::mat4 S = glm::mat4(1.0f);
        S[0][0] = scale_factor;
        S[1][1] = scale_factor;
        triangle.Draw(T,R,S);
    }

}

void Display_regular(){
    glClear(GL_COLOR_BUFFER_BIT);

    // compute transformations here
    int N = 70;
    float c = 0.03f;
    for (int i = 0; i < N; i ++){
        float theta = i * (float)M_PI / 10.0f;
        float r = c * theta;
        float scale_factor = 0.003f*theta;
        glm::mat4 T = glm::translate(glm::mat4(1.0f),
                                     glm::vec3(r * cos(theta) , -r * sin(theta) ,0.0f));
        glm::mat4 R = glm::rotate(glm::mat4(1.0f), -theta,
                                  glm::vec3(0.0f, 0.0f, 1.0f));
        glm::mat4 S = glm::mat4(1.0f);
        S[0][0] = scale_factor;
        S[1][1] = scale_factor;
        triangle.Draw(T,R,S);
    }

}

void ErrorCallback(int error, const char* description) {
    fputs(description, stderr);
}

void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }
}

int main(int argc, char *argv[]) {
    // GLFW Initialization
    if(!glfwInit()) {
        fprintf(stderr, "Failed to initialize GLFW\n");
        return EXIT_FAILURE;
    }

    glfwSetErrorCallback(ErrorCallback);

    // hint GLFW that we would like an OpenGL 3 context (at least)
    // http://www.glfw.org/faq.html#how-do-i-create-an-opengl-30-context
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // attempt to open the window: fails if required version unavailable
    // note some Intel GPUs do not support OpenGL 3.2
    // note update the driver of your graphic card
    GLFWwindow* window = glfwCreateWindow(512, 512, "spiral", NULL, NULL);
    if(!window) {
        glfwTerminate();
        return EXIT_FAILURE;
    }

    // makes the OpenGL context of window current on the calling thread
    glfwMakeContextCurrent(window);

    // set the callback for escape key
    glfwSetKeyCallback(window, KeyCallback);

    // GLEW Initialization (must have a context)
    // https://www.opengl.org/wiki/OpenGL_Loading_Library
    glewExperimental = GL_TRUE; // fixes glew error (see above link)
    if(glewInit() != GLEW_NO_ERROR) {
        fprintf( stderr, "Failed to initialize GLEW\n");
        return EXIT_FAILURE;
    }

    cout << "OpenGL" << glGetString(GL_VERSION) << endl;

    // initialize our OpenGL program
    Init();
    cout << "Pressing the key 'UP' to change between regular spiral and fermat spiral"<< endl;
    
    while(!glfwWindowShouldClose(window)) {
		if (glfwGetKey( window, GLFW_KEY_UP ) == GLFW_PRESS){
			Display_fermat();
		}
		else{
			Display_regular();
		}
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    triangle.Cleanup();

    // close OpenGL window and terminate GLFW
    glfwDestroyWindow(window);
    glfwTerminate();
    return EXIT_SUCCESS;
}

