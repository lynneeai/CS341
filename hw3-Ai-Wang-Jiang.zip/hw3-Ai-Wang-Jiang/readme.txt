1.We change the texture file of the grid to better simulate the water surface, therefore the texture used is not the original picture. The texture picture is downloaded from Google's picture search.

2.For the bonus part of the animation of the grid, we tried using another fomula instead of the sine function. The new animation simulate the waving motion of the water better by combining different waves traveling from x and y directions.To switch between the two versions of animation, please press the direction key "UP".
